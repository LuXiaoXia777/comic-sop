# 项目数据

构建：`python3 <技能目录>/scripts/build.py --root <项目目录>`。首次加 `--init`。初始化仅创建缺失的数据文件，不覆盖已有数据。

- `资料/选题库.json`：数组，每项 `{ "id":"topic-001", "name":"粗稿名称", "outline":"大概剧情" }`。无期次关联。
- `资料/个人规则.json`：`{"rules":[],"changes":[]}`，偏好变更可记录 date 和 text。
- `资料/输出标准.json`：首次从技能复制，后续可按此用户修改；包含 invocation 和 rows。
- `资料/布局参考.json`：来源信息及 entries；每项包含 id、name、source_order、user_note、observed、use_when、application、check。构建旧项目时仅补充缺失文件，已有文件保持原样。
- `资料/期次/issue-001.json`：每期独立源文件。
- `素材/`：生成的速写文件；最终嵌入HTML，不依赖临时文件。

期次结构示意（示意不是预填故事，不复制为真实作品）：

```json
{
  "id":"issue-001",
  "name":"用户本期名称",
  "summary":"该期自己的大纲",
  "tabs":[
    {"label":"脚本内容","blocks":[
      {"type":"table","label":"角色描述","columns":["角色","外形与服饰","关系与动作特征"],"rows":[]},
      {"type":"table","label":"脚本","columns":["页码","场景描述","对白","速写稿"],"rows":[]}
    ]},
    {"label":"图片","kind":"images"},
    {"label":"数据复盘","blocks":[]}
  ]
}
```

脚本每页一行：`["1","整页大致场景","角色：对白",{"type":"image","src":"素材/issue-001-page-1.png","alt":"第1页速写"}]`。

没有出图能力或图片尚未完成时，图片格使用空字符串；向用户解释限制，不能把空单元格当作速写完成。人物表每行3列，脚本表每行4列。不同页可含任意合理格数。表中对白必须和图一致。

首次完成作品才创建期次；不在空白项目填充示例。修改既有作品前把源JSON复制到归档目录，图像使用新版文件名。构建会重写HTML；不要把用户仅在浏览器上传的图宣称为磁盘素材。建议用户导出含图片页面保留浏览器上传结果。

可选 `layoutPlan` 保存内部布局决策，例如 `[{"page":1,"references":["layout-09"],"reason":"先遮挡再揭示观察者","readingOrder":"左到右，上到下","continuity":"门的位置与人物视线保持一致"}]`。不默认显示在脚本表中。
